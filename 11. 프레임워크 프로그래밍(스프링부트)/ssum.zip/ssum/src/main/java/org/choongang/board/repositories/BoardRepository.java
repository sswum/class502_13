package org.choongang.board.repositories;


import org.choongang.board.entities.Board;
import org.choongang.board.entities.QBoard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

public interface BoardRepository extends JpaRepository<Board, Long>, QuerydslPredicateExecutor<Board> {
    default boolean exists(String name) {
        QBoard board = QBoard.board;
        return exists(board.name.eq(name));
    }

    //??? 전체 목록조회하기 위해서..
   // @Query("SELECT DISTINCT b.board.seq FROM Board b WHERE b.board.name")
    //List<String> boardData(@Param("name") String name)
}
