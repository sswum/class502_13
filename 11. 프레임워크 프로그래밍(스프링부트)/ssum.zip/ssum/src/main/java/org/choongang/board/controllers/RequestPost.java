package org.choongang.board.controllers;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class RequestPost {
//게시글을 쓸 때 필수 항목인 것들 null값 못 들어오게

    private Long seq;
    @NotBlank
    private String title;
    @NotBlank
    private String name;
    @NotBlank
    private String content;

    @AssertTrue
    private boolean agree;
}
