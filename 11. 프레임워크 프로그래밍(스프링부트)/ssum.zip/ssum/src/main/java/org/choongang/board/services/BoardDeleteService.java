package org.choongang.board.services;

import lombok.RequiredArgsConstructor;
import org.choongang.board.repositories.BoardRepository;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor

public class BoardDeleteService {
    private final BoardRepository boardRepository;

    public void delete(Long seq) {
        boardRepository.deleteById(seq);
        boardRepository.flush();
    }
}





