package org.choongang.board.services;


import lombok.RequiredArgsConstructor;
import org.choongang.board.controllers.RequestPost;
import org.choongang.board.entities.Board;
import org.choongang.board.repositories.BoardRepository;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
@RequiredArgsConstructor
public class BoardSaveService {

    private final BoardRepository boardRepository;

    public void save(RequestPost form) {
        Long seq = Objects.requireNonNullElse(form.getSeq(), 0L);
        Board board = boardRepository.findById(seq).orElseGet(Board::new);

        // 저장하려는 보드는 seq찾거나 없으면 새로운 보드를 만들어라.
        board.setSeq(form.getSeq());
        board.setTitle(form.getTitle());
        board.setName(form.getName());
        board.setContent(form.getContent());

        // 원래 폼에 있던 내용을 조회하고 set으로 바꿔줘라
        boardRepository.saveAndFlush(board);

    }
}
