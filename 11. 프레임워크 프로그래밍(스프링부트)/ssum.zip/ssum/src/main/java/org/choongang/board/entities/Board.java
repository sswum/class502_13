package org.choongang.board.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.choongang.global.entities.BaseEntitiy;


@NoArgsConstructor @AllArgsConstructor
@Builder
@Data
@Entity
public class Board extends BaseEntitiy {
    @Id @GeneratedValue //기본키 부여
    private Long seq;

    //게시판을 쓸 항목에 대한 설정값 제한.
    @Column(length = 100, nullable = false)
    private String title;

    @Column(length = 10 ,nullable = false)
    private String name;

    @Lob
    @Column(nullable = false)
    private String content;

}
