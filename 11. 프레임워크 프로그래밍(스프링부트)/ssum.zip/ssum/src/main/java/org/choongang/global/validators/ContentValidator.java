package org.choongang.global.validators;

public interface ContentValidator {

    /**
     * 콘텐츠에 특수문자를 제외한 모든 문자열을 들어올 수 있게끔 정의
     */

    default boolean contentCheck(String content) {
        String pattern = ".*[0-9a-zA-Zㄱ-ㅎ가-힣\\s\\t\\f]+.*";
        return content.matches(pattern);
    }
}
