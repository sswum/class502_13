package org.choongang.board.controllers;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.choongang.board.entities.Board;
import org.choongang.board.services.BoardDeleteService;
import org.choongang.board.services.BoardInfoService;
import org.choongang.board.services.BoardSaveService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@Controller
@RequestMapping("/board")
public class BoardController {

    private BoardSaveService boardSaveService;
    private BoardInfoService infoService;
    private final BoardDeleteService deleteService;

    @GetMapping("/write")
    public String write(@ModelAttribute RequestPost form) {
        return "board/write";
    }

    @GetMapping("/update/{seq}") //글쓰기 후 (수정, 등록)이 가능해지게끔
    public String update(@PathVariable("seq") Long seq, Model model) {
       RequestPost form = infoService.getForm(seq);
       model.addAttribute("requestPost",form);

        return "board/update";
    }

    @PostMapping("/save") //그리고 저장
    public String save(@Valid RequestPost form, Errors errors) { //@Valid는 validate와 비슷하게 스프링프레임워크에 들어간 것.
        String mode = form.getSeq() == null ? "update" : "write";
        if (errors.hasErrors()) {
            return "board/" + mode;
        }
        boardSaveService.save(form);
        return "redirect:/board/list";
    }

    @GetMapping("/view/{seq}")
    public String view(@PathVariable("seq") Long seq, Model model) {
        Board data = infoService.get(seq);

        model.addAttribute("data", data);

        return "board/view";
    }

    @GetMapping("/list")
    public String list(@ModelAttribute BoardSearch search, Model model) {
        Page<Board> data = infoService.getList(search);
        model.addAttribute("items", data.getContent());
        return "board/list";
    }

    @DeleteMapping("/delete/{seq}")
    public String delete(@PathVariable("seq") Long seq) {
        deleteService.delete(seq);

        return "redirect:/board/list";
    }

}
