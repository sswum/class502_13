package org.choongang.global.entities;

import jakarta.persistence.Column;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDateTime;

public abstract class BaseEntitiy {

    @CreatedDate
    @Column(updatable = false) //날짜는 공통 속성으로 들어가서 따로 빼는게 나을깡?
    private LocalDateTime createdAt;

}
