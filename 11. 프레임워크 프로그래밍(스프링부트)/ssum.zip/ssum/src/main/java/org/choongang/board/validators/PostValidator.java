package org.choongang.board.validators;

import lombok.RequiredArgsConstructor;
import org.aspectj.weaver.tools.ContextBasedMatcher;
import org.choongang.board.controllers.RequestPost;
import org.choongang.board.repositories.BoardRepository;
import org.choongang.global.validators.ContentValidator;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@RequiredArgsConstructor
@Component
public class PostValidator implements Validator, ContentValidator {

    private final BoardRepository boardRepository;

    @Override
    public boolean supports(Class<?> clazz) {
        return clazz.isAssignableFrom(RequestPost.class);
        //내가 만든 커맨드 객체 검증
    }

    @Override
    public void validate(Object target, Errors errors) {
        if (errors.hasErrors()) {
            return; // 에러가 나면 고대로 반환
        }

        /**
         * 1. 이미 누가 쓴 이름인지 체크
         * 2. 같은 게시물 제목이 있는지 체크
         * 3. contents 형식 체크 (특수문자가 들어가있는지 체크)
         */

        RequestPost form= (RequestPost) target;
        String title = form.getTitle();
        String name = form.getName();
        String content = form.getContent();

        //1. 이미 누가 쓴 이름 인지 체크
        if (boardRepository.exists(name)) {
            errors.rejectValue("name","Duplicated");
        }

        // 2. 같은 게시물 제목이 있는지 체크
        if (boardRepository.exists(title)) {
            errors.rejectValue("title","Duplicated1");
        }
        // 3. contents 형식 체크 (글자만 허용하게끔)
        if (!contentCheck(content)) {
            errors.rejectValue("content","Mismatch");
        }
    }
}
