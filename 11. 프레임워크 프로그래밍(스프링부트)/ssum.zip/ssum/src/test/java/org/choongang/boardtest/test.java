package org.choongang.boardtest;

import org.choongang.board.entities.Board;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

//@TestPropertySource()
@SpringBootTest
public class test {





}