package org.choongang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsumApplicationTests {

	@Test
	void contextLoads() {
	}

}
